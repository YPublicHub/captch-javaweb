# captcha-java-demo
云片验证码java演示

# demo运行步骤
* 修改index.html
```
  new YpRiddler({
    expired: 10,
    mode: 'dialog',
    container: document.getElementById('cbox'),    //<-这里填入你要绑定的元素
    appId: '',                                    //<-这里填入你的chaptchID
    version: 'v1',
    onError: function (param) {
      if(param.code == 429) {
        alert('请求过于频繁，请稍后再试！')
        return
      }
    },
    onSuccess: function (validInfo, close) {
      // 成功回调
    },
    onFail: function (code, msg, retry) {
    },
    beforeStart: function (next) {
    },
    onExit: function() {
    }
  })
}
```

* 修改 LoginServlet.java
```
    private static final String captchaId = "YOUR_CAPTCHA_ID"; // 验证码id
    private static final String secretId = "YOUR_SECRET_ID"; // 密钥对id
    private static final String secretKey = "YOUR_SECRET_KEY"; // 密钥对key
```

* `mvn tomcat7:run`
* 浏览器访问 http://localhost:8181/ 查看演示