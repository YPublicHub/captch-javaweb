        

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


        // http maven包 
        <dependency>
                <groupId>org.apache.httpcomponents</groupId>
                <artifactId>httpclient</artifactId>
                <version>4.5.2</version>
        </dependency>

        // 倒入依赖包
        import org.apache.http.HttpEntity;
        import org.apache.http.NameValuePair;
        import org.apache.http.client.entity.UrlEncodedFormEntity;
        import org.apache.http.client.methods.CloseableHttpResponse;
        import org.apache.http.client.methods.HttpPost;
        import org.apache.http.impl.client.CloseableHttpClient;
        import org.apache.http.impl.client.HttpClients;
        import org.apache.http.message.BasicNameValuePair;
        import org.apache.http.util.EntityUtils;

        // MD5 算法 maven包
        <dependency>
                <groupId>org.apache.directory.studio</groupId>
                <artifactId>org.apache.commons.codec</artifactId>
                <version>1.8</version>
        </dependency>

        //倒入依赖包
        import org.apache.commons.codec.digest.DigestUtils;




        params.put("captchaId", captchaId);
        params.put("token", token);
        params.put("authenticate", authenticate);
        // 公共参数
        params.put("secretId", secretId);
        params.put("version", VERSION);
        params.put("timestamp", String.valueOf(System.currentTimeMillis()));
        params.put("nonce", String.valueOf(ThreadLocalRandom.current().nextInt(1,99999)));
